## Test environments
* Windows10 R 4.2.0 local development environment
* Windows10 R 4.2.2 local development environment
* GitHub Actions:
  * macOS-latest,  R: release
  * windows-latest, R: release
  * ubuntu-latest,   R: devel
  * ubuntu-latest,   R: release
* Winbuilder: release, devel.

## R CMD check results

0 ERRORs | 0 WARNINGs | 0 NOTES. 

## Downstream dependencies

I have also run R CMD check on downstream dependencies of emdi:
No ERRORs or WARNINGs found

