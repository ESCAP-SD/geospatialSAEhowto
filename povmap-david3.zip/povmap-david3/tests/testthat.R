library(testthat)
library(povmap)

test_check("povmap")
